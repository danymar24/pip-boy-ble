// --- 7. SERIAL PARSER ---
  Pip.serialBuffer = "";
  Pip.isProcessing = false;

  Pip.processBuffer = function () {
    if (Pip.serialBuffer.indexOf('\n') === -1) {
      Pip.isProcessing = false;
      return;
    }

    var lines = Pip.serialBuffer.split('\n');
    Pip.serialBuffer = lines.pop();

    for (var i = 0; i < lines.length; i++) {
      var cmd = lines[i].trim();
      if (cmd.length === 0) continue;
      var parts = cmd.split("|");
      if (parts.length > 1) {

        if (parts[0] === "NOTIF") {
          var msg = parts[1], cIdx = msg.indexOf(":"), sender = "UNKNOWN", body = msg;
          if (cIdx > -1) {
            sender = msg.substring(0, cIdx).trim();
            body = msg.substring(cIdx + 1).trim();
          }

          if (sender.toUpperCase().indexOf("SPOT") > -1) continue;

          Pip.notifications.unshift({ title: sender, body: body });
          if (Pip.notifications.length > 5) Pip.notifications.pop();

          Pip.showNotification("> INCOMING TRANSMISSION", msg);
          if (Pip.currentMenuTitle === "COMMUNICATIONS UPLINK") Pip.submenuUplink();
        }
        else if (parts[0] === "TIME") {
          var unixSeconds = parseFloat(parts[1]);
          if (!isNaN(unixSeconds)) setTime(unixSeconds);
        }
        else if (parts[0] === "SET") {
          var setMsg = parts[1], setIdx = setMsg.indexOf(":");
          if (setIdx > -1) {
            var settingKey = setMsg.substring(0, setIdx).trim().toUpperCase();
            var settingValue = setMsg.substring(setIdx + 1).trim();

            if (settingKey === "COLOR") {
              var colorVal = parseInt(settingValue);
              var r5 = (colorVal >> 11) & 0x1F, g6 = (colorVal >> 5) & 0x3F, b5 = colorVal & 0x1F;
              var r = r5 / 31.0, gr = g6 / 63.0, b = b5 / 31.0;
              var r8 = Math.round(r * 255), g8 = Math.round(gr * 255), b8 = Math.round(b * 255);

              var pal = [new Uint16Array(16), new Uint16Array(16), new Uint16Array(16), new Uint16Array(16)];
              for (var j = 0; j < 16; j++) {
                pal[0][j] = g.toColor((j / 15) * r, (j / 15) * gr, (j / 15) * b);
                pal[1][j] = g.toColor((j / 30) * r, (j / 30) * gr, (j / 30) * b);
                pal[2][j] = g.toColor((j / 10) * r, (j / 10) * gr, (j / 10) * b);
                pal[3][j] = g.toColor((j / 20) * r, (j / 20) * gr, (j / 20) * b);
              }
              if (typeof Pip.setPalette === 'function') Pip.setPalette(pal);

              g.theme.fg = colorVal;
              g.theme.fg2 = colorVal;
              if (typeof bC !== 'undefined' && bC.theme) bC.theme.fg = colorVal;
              if (typeof global.fg !== 'undefined') global.fg = colorVal;
              if (typeof global.fg2 !== 'undefined') global.fg2 = colorVal;

              if (typeof settings !== 'undefined' && settings.color) {
                settings.color.r = r8; settings.color.g = g8; settings.color.b = b8;
              }

              Pip.showNotification("> THEME OVERRIDE", "Color profile updated.");
              if (Pip.currentMenuTitle === "COMMUNICATIONS UPLINK") Pip.submenuUplink();
            }
          }
        }
        else if (parts[0] === "CLEAR") {
          var clearCmd = parts[1].trim();
          if (clearCmd === "ALL") {
            Pip.notifications = [];
          } else {
            var filteredInbox = [];
            for (var k = 0; k < Pip.notifications.length; k++) {
              if (Pip.notifications[k].title !== clearCmd) filteredInbox.push(Pip.notifications[k]);
            }
            Pip.notifications = filteredInbox;
          }
          if (Pip.currentMenuTitle === "COMMUNICATIONS UPLINK") Pip.submenuUplink();
        }
        else if (parts[0] === "ALARM") {
          var aMsg = parts[1] || "";
          var cIdx = aMsg.indexOf(":");
          var aCmd = cIdx > -1 ? aMsg.substring(0, cIdx).trim().toUpperCase() : aMsg.trim().toUpperCase();
          var aVal = cIdx > -1 ? aMsg.substring(cIdx + 1).trim() : "";

          if (aCmd === "SET") Pip.alarmState.time = aVal;
          else if (aCmd === "ON") Pip.alarmState.enabled = true;
          else if (aCmd === "OFF") Pip.alarmState.enabled = false;
          else if (aCmd === "SOUND") Pip.alarmState.sound = aVal;
          else if (aCmd === "REPEAT") Pip.alarmState.repeat = (aVal === "1");
          else if (aCmd === "TRIGGER") Pip.triggerAlarm();
          else if (aCmd === "SNOOZE") {
            var d = new Date();
            d.setMinutes(d.getMinutes() + 9);
            Pip.alarmState.snoozeTime = zPad(d.getHours()) + ":" + zPad(d.getMinutes());
            Pip.showNotification("> ALARM SNOOZED", "Snoozing for 9 minutes.");
          }
          else if (aCmd === "GET") {
            var status = "ALARM_STATUS|" + Pip.alarmState.time + "|" +
              (Pip.alarmState.enabled ? "1" : "0") + "|" +
              Pip.alarmState.sound + "|" +
              (Pip.alarmState.repeat ? "1" : "0") + "\n";
            try { Serial3.write(status); } catch (e) { }
          }
        }
      }
    }

    if (Pip.serialBuffer.indexOf('\n') !== -1) setTimeout(Pip.processBuffer, 10);
    else Pip.isProcessing = false;
  };

  Pip.handleData = function (d) {
    Pip.serialBuffer += d;
    if (Pip.serialBuffer.length > 512) Pip.serialBuffer = "";
    if (Pip.serialBuffer.indexOf('\n') !== -1 && !Pip.isProcessing) {
      Pip.isProcessing = true;
      setTimeout(Pip.processBuffer, 10);
    }
  };

  try { Serial3.on('data', Pip.handleData); } catch (e) { }
} // CLOSES THE BOOTLOADER WRAPPER

// EXECUTE
initUplinkDaemon();