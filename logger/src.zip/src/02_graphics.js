// --- 4. THE FREEZE-FRAME OVERLAY ---
  bC.flip = function (a) {
    if (Pip.isNotifActive) return;
    return Pip.originalFlip.apply(bC, arguments);
  };

  Pip.showNotification = function (header, text) {
    Pip.audioStart("UI/ALERT.wav");
    Pip.notifHeader = header;
    Pip.notifBody = text;
    Pip.isNotifActive = true;

    var w = g.getWidth(), h = g.getHeight();
    var x1 = w * 0.1, y1 = h * 0.25, x2 = w * 0.9, y2 = h * 0.75;

    g.setColor(0).fillRect(x1, y1, x2, y2);
    g.setColor(g.theme.fg).drawRect(x1, y1, x2, y2);

    g.setFont("Vector", 20).setFontAlign(0, -1);
    g.drawString(header, w / 2, y1 + 10);
    g.drawLine(x1 + 10, y1 + 35, x2 - 10, y1 + 35);

    g.setFont("Vector", 18).setFontAlign(-1, -1);
    var cx = x1 + 15, cy = y1 + 45;
    for (var i = 0; i < text.length; i++) {
      if (text[i] === '\n' || text[i] === '\r') continue;
      g.drawString(text[i], cx, cy);
      cx += 14;
      if (cx > x2 - 15) { cx = x1 + 15; cy += 24; }
      if (cy > y2 - 20) break;
    }

    g.setFontAlign(-1, -1);
    g.setFont("6x8", 1);

    if (Pip.notifTimeout) clearTimeout(Pip.notifTimeout);
    Pip.notifTimeout = setTimeout(function () {
      Pip.isNotifActive = false;
      bC.flip();
    }, 5000);
  };