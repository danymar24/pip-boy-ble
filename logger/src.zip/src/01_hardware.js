// --- 2. THE HARDWARE WATCHDOG ---
  Pip.releaseKnob = function () {
    if (typeof Pip.removeSubmenu === 'function') {
      Pip.removeSubmenu();
      Pip.removeSubmenu = null;
    }
  };

  setInterval(function () {
    if (typeof MODE !== 'undefined' && Pip.lastMode !== MODE) {
      Pip.lastMode = MODE;
      Pip.releaseKnob();
      Pip.currentMenuTitle = "";
    }
  }, 500);

  // --- 3. MENU PIPELINE (With Safe Context) ---
  E.showMenu = function (menu) {
    Pip.releaseKnob();
    if (menu && menu[""] && menu[""].title) Pip.currentMenuTitle = menu[""].title;
    else Pip.currentMenuTitle = "";
    return Pip.originalShowMenu.apply(E, arguments);
  };